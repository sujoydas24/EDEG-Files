import Footer from './components/Footer';
import NavBar from './components/NavBar';
import LoginPage from './components/Login'

function App() {
  return (
    <>
    <NavBar/>
    <LoginPage/>
    <Footer/>
    </>
  )
}

export default App